# Study 2 — Flip (curious)

## What it does

- A blank sheet lies face down.
- Hover near an edge: a white glove fades in gripping that edge and tugs it. A chevron shows the drag direction.
- Drag across to turn the sheet over around its middle. The front face is revealed.

## Visual components

- Stage: lighter grey column (`#e4e3df`), tag "Study 2 · flip · curious", ↺ button.
- Sheet: 230×300 px, drawn as 120 thin strips on a rigid turn with a small flex in the middle. Strips are sorted by height and shaded by tilt. Soft blurred shadow.
- Back face: blank paper with very faint show-through of the front (alpha 0.012).
- Front face: `front_plain.svg`, mirrored while turning so it reads correctly.
- Glove: low-poly white glove drawn with facets, gripping the middle of the nearest edge. Pulls back slightly with each tug.
- Cue: two stemless chevrons sliding across the sheet in the drag direction. Hidden while dragging.
- Click ripple when pressing away from an edge.

## States and transitions

| State | Entered by | Behavior |
|---|---|---|
| `back` | start, reset | Sheet face down. Hover shows glove and tugs. Drag possible. |
| `turning` | release past 90° or drag past 144° (`0.8π`) | Spring carries angle `phi` to 180°. |
| `front` | `phi` settles at 180° | End state. No further input. Reset with ↺. |

Release before 90° springs the sheet back to flat and stays in `back`.

## User actions and feedback

| Action | Visual | Sound | Cursor |
|---|---|---|---|
| Hover within 26px of an edge | Glove fades in at edge center, edge tugs up to ~0.22 rad a couple of times a second, chevrons slide | Faint rustle on tugs | hidden (`none`) |
| Move to another edge | Glove resets and re-grips the new edge | Rustle | hidden |
| Press on edge | Edge locked, drag starts | Rustle | hidden |
| Drag across | Sheet turns, `phi = progress × 180°` (travel measured against 95% of sheet size along the drag direction) | High-pass noise tracks turn speed; a rising note every 30° | hidden |
| Settle on front | Sheet flat, front showing | Two soft falling tones (330, 262 Hz) | default |
| Press away from edge | Ripple | none | default |

All four edges work. Input is mouse or pen only.

## Where it is (`index.html`)

| Part | Lines |
|---|---|
| Page CSS, stage, canvas, ↺ button | 1–24 |
| Canvas setup, audio, shared helpers, inline assets | 26–255 |
| Constants (`PW`, `PH`, `K`, `EDGE`) | 262 |
| Face canvases (`buildFaces`) | 263–271 |
| State object and `resetStudy` | 272–278 |
| Edge table (`EDGES`) and `nearestEdge` | 281–291 |
| Pointer handlers, `endDrag` | 293–317 |
| Per-frame logic (hover, tug, spring, sounds, state change) | 319–357 |
| Turn geometry (`sample`) | 359–363 |
| Sheet renderer (`drawCard`) | 364–396 |
| Glove position and arrow cue (`edgePoint`, `drawGripAndArrow`) | 397–427 |
| Glove drawing (`GL`, `facet`, `quad`, `glove`) | 428–447 |

Tunable values: `EDGE` (hover band width), `K` (perspective), tug formula at line 335, spring constants at line 340, `0.8π` auto-finish at line 339.

## Dependencies and assets

- No external dependencies, no network.
- Needs Canvas 2D with `ctx.filter` (shadow blur) and Web Audio.
- Uses `front_plain.svg` (inline, via `IMG.front_plain`). The back face and glove are drawn in code.
- `assets/` has the shared SVGs for reference only.

## Notes for chaining

- To hand off to the next study, hook the `front` transition (line 347: `S.state = 'front'`).
- `window.resetStudy()` restores the initial state and keeps the audio voice alive.
