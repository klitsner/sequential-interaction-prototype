# Study 4 — Throw (liberating)

## What it does

- A crumpled statement ball sits on the floor of a room, a can against the back wall.
- Grab the ball (it tightens in your fist and trembles), then throw it at the can.
- The ball leaves at your cursor speed, then eases toward a cleaner arc into the can.
- A miss adds interest to the "TOTAL DEBT" counter and the ball rolls back to its start.
- A hit: the can swallows the counter's digits, swells, then lets them go. The counter ends at `$0.00` and the room brightens.

## Visual components

- Room: wall, floor with board seams, window with sill and a light patch, couch against the back wall. Low-poly, flat facets. Perspective through `worldToScreen` (x, depth z, height h).
- Can: `can.svg` at depth `CAN_Z = 1.0`, swells and wobbles during the success sequence.
- Ball: 8-frame roll sprite set, frame chosen by accumulated roll angle. Floor shadow shrinks and fades with height.
- Held cue: four white chevrons run from the ball toward the can.
- Flight trail: faint ghost balls every 1/14 s.
- Counter: "TOTAL DEBT" label and amount at the top of the stage. Shakes on a miss.
- Floating "+amount" text from the landing spot to the counter on a miss.
- Digits and white confetti triangles ("motes") during the success sequence.
- Brightness overlay (`brighten`): rises a little with ball height in flight, and to 0.3 after success.
- Click ripple when pressing away from the ball.

## States and transitions

| State | Entered by | Behavior |
|---|---|---|
| `ready` | start, reset, end of rollback | Ball rests at start. Hover within 60px lifts it slightly. |
| `held` | press within 60px of ball | Ball follows the cursor in world space (x clamped ±0.6, height up to 1.2). Squeezed and trembling. |
| `fly` | release | Ball launches with velocity from the last ~90 ms of cursor motion. Gravity `G`. |
| `rollback` | ball comes to rest on the floor after bouncing | Rolls and hops back to the start, then `ready`. |
| `in` | ball drops through the can mouth | Success sequence (`eat` → `hold` → `release` → `zero`). End state. Reset with ↺. |

Launch rule: counts as a throw only if upward cursor speed is above 220 px/s. Slower releases just drop the ball, and no interest is added.

Aim assist: over the first 0.55 s (`EASE_FOR`) the velocity blends toward the ideal throw into the can, weights `AIM` (side) and `AIMZ` (depth and height) both 0.9. Ideal flight time is `T_FLIGHT` 1.35 s.

Other collisions:
- Over the can mouth while descending: goes in.
- Low side hit on the can: bounces back and the can swells briefly.
- Floor: bounces at 0.32 restitution, halves sideways and depth speed, rolls back once the bounce is below 0.25.

## User actions and feedback

| Action | Visual | Sound | Cursor |
|---|---|---|---|
| Hover ball | Ball lifts slightly | none | `grab` |
| Press ball | Squeezed 20%, folds darker, trembles | Scrunch (rustle + burst) | `grabbing` |
| Hold | Chevrons run toward the can | Occasional rustle | `grabbing` |
| Release (throw) | Ball flies, spins, leaves a trail, scene brightens with height | Whoosh; sine voice rises with height | default |
| Release (too slow) | Ball drops | none | default |
| Floor impact | Bounce | Thud scaled to impact, rustle | default |
| Miss, ball at rest | Counter rises by 3% of its value, "+amount" floats up, counter shakes, ball rolls back | Low sour pair (98, 92.5 Hz) + thud | default |
| Hit | Digits arc into the can one by one, can swells to 14% then 16% with a fast wobble, holds 0.7 s, digits burst out and drift, motes rise, counter fades to `$0.00`, room brightens | Short tone per digit; woosh and rising chord (262, 330, 392, 523 Hz) on release | default |
| Press away from ball | Ripple | none | default |

Input is mouse or pen only.

## Where it is (`index.html`)

| Part | Lines |
|---|---|
| Page CSS, stage, canvas, ↺ button | 1–24 |
| Canvas setup, audio, shared helpers, inline assets | 26–135 |
| Scene helpers: `worldToScreen`, `drawRoom`, `drawCan`, `canH` | 142–170 |
| `makeBall`, `triShade`, noise sound helpers | 173–253 |
| Constants (`START`, `G`, `AIM`, `T_FLIGHT`, `EASE_FOR`, `VZK`, `AIMZ`) | 262–263 |
| Roll sprites (`ROLL`) and `drawRollBall` | 266–275 |
| State object and `resetStudy` | 276–283 |
| Coordinate helpers (`ballR`, `ballScreen`, `screenToWorld`, `idealFrom`) | 284–295 |
| Pointer handlers, launch velocity | 297–326 |
| Frame loop | 329–417 |
| ↳ held state | 336–340 |
| ↳ fly state, aim assist, can and floor collisions | 341–366 |
| ↳ rollback state | 367–374 |
| ↳ in state | 375–378 |
| ↳ held cue (chevrons) | 402–415 |
| `drawTheBall` (shadow, squeeze, tremble) | 418–431 |
| `drawFurniture` (window, couch) | 432–463 |
| Debt counter: `money`, `addInterest`, `drawDebt` | 464–504 |
| Success sequence: `startConsume`, `updateConsume` | 505–549 |
| Can swell drawing (`drawCanSwell`) | 550–554 |

Tunable values: `G`, `AIM`, `AIMZ`, `T_FLIGHT`, `EASE_FOR`, launch threshold `220` (line 322), interest rate `0.03` (`addInterest`), start amount `debt: 12024` (`resetStudy`), swell amounts (`updateConsume`).

## Dependencies and assets

- No external dependencies, no network.
- Needs Canvas 2D with `ctx.filter` (ball darkening while held) and Web Audio.
- Uses `can.svg` (inline, via `IMG.can`) and 8 roll-sprite SVGs (inline `ROLL`, standalone copies `assets/ball_roll_01..08.svg`).
- `front.svg`, `front_plain.svg`, `back.svg` are carried in the shared `ASSETS` block but not drawn here.
- Counter text uses `Helvetica, Arial, sans-serif`.

## Notes for chaining

- Success hook: line 356 sets `S.state = 'in'` and calls `startConsume`. The sequence ends when `S.phase` becomes `'zero'` (line 543).
- The counter starts from `S.debt` in `resetStudy`. A connected prototype can pass the value in instead of the hard-coded start.
- `window.resetStudy()` restores the initial state and keeps the throw sound voice object. It also resets `brighten` to 0.
