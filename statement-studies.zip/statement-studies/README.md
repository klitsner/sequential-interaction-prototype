# Statement studies

Four interaction studies on one subject: a statement sheet and what you can do to it. Each study is a single self-contained `index.html`.

| Folder | Study | Verb |
|---|---|---|
| `study-1-pick-up/` | Study 1 | Pick up (drafty) |
| `study-2-flip/` | Study 2 | Flip (curious) |
| `study-3-crumple/` | Study 3 | Crumple (crushing) |
| `study-4-throw/` | Study 4 | Throw (liberating) |

Each folder has `index.html`, `STUDY.md`, and `assets/`.

## Run

1. Unzip.
2. Open `study-N-.../index.html` in a desktop browser.
3. Or serve the folder: `python3 -m http.server 8000`, then open `http://localhost:8000/study-1-pick-up/`.
4. Click once on the stage so the browser allows sound.
5. Use the ↺ button (top right of the stage) to reset a study.

## Requirements

- Desktop browser with a mouse or pen. Touch input is ignored by design.
- No build step, no npm packages, no network requests, no web fonts.
- Browser features used: Canvas 2D (including `ctx.filter`), Web Audio, Pointer Events.

## Layout on screen

- Stage is a phone-sized column: 390×844 on viewports 600px wide or more, otherwise fills the window up to 430×932.
- Drawing is on one `<canvas id="c">` per study, scaled by `devicePixelRatio` (max 2).

## Shared code

- Lines 25–257 of every `index.html` are the same across all four studies. Study-specific code starts at line 258 with a `// STUDY n` comment.
- The shared block holds: canvas setup and `resize()`, Web Audio helpers, the inline SVG assets, the low-poly room, can and crumpled-ball helpers, noise sounds, `isMouse()`.
- Every study keeps its state in one global object `S` and defines `window.resetStudy()`. The ↺ button calls it.
- Everything is global script scope (`cvs`, `ctx`, `W`, `H`, `S`, `PW`, `PH`, `BALL`, `glove`, `frame`, ...). Studies will collide if loaded into one page without namespacing.
- Unused leftovers in the shared block: `N`, `threadY`, `SCALE`, `ghost`, `touchRipple`, `ghostCursor`, and `#hint` (always hidden).

## Assets

- All assets are inline SVG strings inside `index.html`: `ASSETS` (line 136), plus `GLOVES` in Study 3 and `ROLL` in Study 4.
- `assets/` holds the same SVGs as standalone files for reference. The studies do not load these files.
- To change an asset, edit the inline string in `index.html`.

## Conventions

- Palette is greys and warm off-white (`#d6d5d1` wall, `#c4c3be` floor, `#2b2b2a` ink). Red `#c23b2e` appears only on the sheet's text.
- Low-poly look: flat facets, no outlines, hairline stroke in the fill colour to hide seams.
- Sounds are synthesized (oscillators and filtered noise). No audio files.
