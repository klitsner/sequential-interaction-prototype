# Study 1 — Pick Up (drafty)

## What it does

- A sheet lies face down on a grid floor.
- A draft lifts its bottom edge every 1.5 s and curls it back, flashing the red text on the other side.
- Hovering the sheet takes over from the draft and lifts the edge by hand.
- Press and drag up to peel the whole sheet off the floor. It ends raised toward the viewer, red-lined side showing.

## Visual components

- Stage: grey column, grid floor (40px lines), tag "Study 1 · pick up · drafty", ↺ button.
- Sheet: 230×300 px, drawn as thin strips bent around a cylinder (flat part + lifted part). Lifted strips are lit by a fixed light and cast a blurred shadow.
- Underside: red "words" as lines of text, heavy headline first and last. Built once on an offscreen canvas.
- Wind streaks: thin white curved lines crossing the stage during a gust.
- Click ripple: soft grey circle when pressing off the sheet.

## States and transitions

| State | Entered by | Behavior |
|---|---|---|
| `floor` | start, reset, release before 80% | Idle. Draft gusts lift the edge. Hover lifts it ~80px instead. |
| `drag` | press on sheet | Edge follows upward drag at 1.25× cursor travel. |
| `finishing` | drag reaches full height, or release past 80% | Sheet finishes peeling, then rises (`S.u` 0→1 over 0.8 s). |
| `held` | `S.u` reaches 1 | End state. No further input. Reset with ↺. |

Gust envelope: rise 0.3 s, hold 0.5 s, fall 0.3 s, rest until the next 1.5 s mark. First gust starts 0.4 s after reset.

## User actions and feedback

| Action | Visual | Sound | Cursor |
|---|---|---|---|
| Idle | Edge lifts and flutters on each gust, streaks cross | Low wind noise swells with the gust | default |
| Hover sheet | Edge lifts to ~80px, small bob | Wind voice continues | open hand (`grab`) |
| Press on sheet | Edge grabs | Short rustle | `grabbing` |
| Drag up | Sheet peels, shadow grows | Band-passed noise follows peel speed | `grabbing` |
| Release early | Sheet drops back | Soft burst | `grab` / default |
| Finish | Sheet rises, held | Soft tone (523 Hz) + airy noise | default |
| Press off sheet | Ripple | none | default |

Input is mouse or pen only (`isMouse`). Touch is ignored.

## Where it is (`index.html`)

| Part | Lines |
|---|---|
| Page CSS, stage, canvas, ↺ button | 1–24 |
| Canvas setup, audio, pointer helper, reset hookup | 26–134 |
| Inline assets, room, ball and noise helpers (shared, mostly unused here) | 136–255 |
| Constants (`PW`, `PH`, `K`, `HL`, `PERIOD`) | 263 |
| Underside texture (`buildUnder`) | 264–277 |
| State object and `resetStudy` | 278–285 |
| Hit test (`origin`, `overPaper`) | 286–287 |
| Pointer handlers | 289–306 |
| Gust timing and envelope | 314–317 |
| Wind sound, streak spawning | 318–323 |
| Target height and curl per state | 328–346 |
| Easing toward target, edge switching | 347–349 |
| Background, streaks drawing | 351–367 |
| Sheet renderer (`drawSheet`) | 373–430 |

Tunable values: `PERIOD` (gust interval), `HL` (how high the held sheet rises), `K` (perspective scale), `SIDES` (line 308, draft direction; only `'bottom'` is active), the `0.36` gust lift factor and `1.25` drag multiplier in `frame()`.

## Dependencies and assets

- No external dependencies, no network.
- Needs Canvas 2D with `ctx.filter` (blur shadows) and Web Audio.
- Uses no inline SVG assets at runtime. The underside is drawn in code. The shared `ASSETS` block is carried along but unused here.
- `assets/` has the shared SVGs for reference only.

## Notes for chaining

- To hand off to the next study, hook the `held` transition (line 337: `S.state = 'held'`).
- `window.resetStudy()` restores the initial state and keeps the audio voices alive.
