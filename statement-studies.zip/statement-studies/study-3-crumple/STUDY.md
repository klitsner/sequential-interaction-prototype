# Study 3 — Crumple (crushing)

## What it does

- The statement sits on plain ground.
- Hover: two open white-glove hands fade in at its sides.
- Press and hold: the hands close in, fingers curl, and they shake harder as the sheet is crushed into a low-poly paper ball.

## Visual components

- Stage: lighter grey column (`#e4e3df`), tag "Study 3 · crumple · crushing", ↺ button.
- Sheet: `front.svg` (statement mock with folded facets), clipped by a 22-point outline that morphs from a rectangle to a ball outline.
- Ball: low-poly crumpled ball (`makeBall(17)`), crossfaded in over the last 40% of the crush. Triangle fan shading over the morphing outline before that.
- Gloves: 5 SVG frames, open to fist, picked by curl amount. Right hand is the left hand mirrored.
- Floor shadow ellipse that shrinks with the sheet.
- Click ripple when pressing away from the sheet.

## States and transitions

| State | Entered by | Behavior |
|---|---|---|
| `flat` | start, reset, release before finishing | Sheet shows its current crush level `S.c`. Eases back to 85% of the level at release. |
| `crush` | press on sheet | Hands close (`S.close` → 1). Once close > 0.8, `S.c` rises at `0.16 + 0.75·c` per second: slow at first, then it gives way. |
| `ball` | `S.c` reaches 1 | Ball bounces and settles. No further input. Reset with ↺. |

Releasing mid-crush keeps most progress, so repeated presses finish the ball.

## User actions and feedback

| Action | Visual | Sound | Cursor |
|---|---|---|---|
| Hover sheet | Gloves fade in, open, hovering ~20px outside the edges with a small bob | none | hidden |
| Press and hold on sheet | Gloves close onto edges, fingers curl, sheet and gloves shake (shake grows with `S.c`) | Thud + rustle on press; low sawtooth groan rising in level; random noise crackles, denser as it crushes | hidden |
| Release before finish | Gloves open and fade if pointer leaves, sheet relaxes slightly | Groan stops | default or hidden |
| Crush completes | Ball pops in with a short bounce, gloves fade | Heavy thud (55 Hz) + noise burst | default |
| Press away from sheet | Ripple | none | default |

Input is mouse or pen only.

## Where it is (`index.html`)

| Part | Lines |
|---|---|
| Page CSS, stage, canvas, ↺ button | 1–24 |
| Canvas setup, audio, shared helpers, inline assets, `makeBall`, `drawBall` | 26–255 |
| Constants (`HW`, `HH`, `M`, `BALL_R`), `BALL` | 262–263 |
| Outline morph targets (`RECT`, `TARGET`) | 264–272 |
| State object and `resetStudy` | 273–278 |
| Layout and hit test (`center`, `halfW`, `overPaper`) | 279–281 |
| Pointer handlers | 283–299 |
| Per-frame logic (hover, close, crush rate, shake, sounds, state change) | 301–321 |
| Sheet outline, front image clip, triangle fan, ball crossfade | 322–345 |
| Hands drawing (`handA`, gap, curl) | 346–352 |
| Ripples, loop | 353–355 |
| Glove frames (`GLOVES`) and `glove()` | 357–365 |

Tunable values: `HW`/`HH` (sheet half size), `M` (outline points), `BALL_R`, crush rate `0.16 + c*0.75` (line 309), shake `0.6 + c*7`, the `0.85` release retention (line 298), glove scale `0.82` in `glove()`.

## Dependencies and assets

- No external dependencies, no network.
- Needs Canvas 2D and Web Audio.
- Uses `front.svg` (inline, via `IMG.front`) and 5 glove SVGs (inline `GLOVES`, standalone copies `assets/glove_01..05.svg`).
- The ball is generated in code from a seed (`makeBall(17)`).

## Notes for chaining

- To hand off to the next study, hook the `ball` transition (line 314: `S.state = 'ball'`). The ball ends centered at `(W/2, H·0.47)` with radius `BALL_R` (50).
- Study 4 starts with a ball on the floor of a room, drawn with its own 8-frame roll sprite set rather than this ball.
- `window.resetStudy()` restores the initial state and keeps the groan voice object.
